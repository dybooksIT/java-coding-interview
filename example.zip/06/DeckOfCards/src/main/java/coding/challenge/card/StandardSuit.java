package coding.challenge.card;

public enum StandardSuit {
    SPADES, HEARTS, DIAMONDS, CLUBS;
}