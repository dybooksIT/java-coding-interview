package coding.challenge.good;

public interface SocketConnection extends Connection {
    public void socket();
}