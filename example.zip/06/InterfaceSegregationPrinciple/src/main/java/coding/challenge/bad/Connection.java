package coding.challenge.bad;

public interface Connection {
    public void socket();
    public void http();
    public void connect();
}