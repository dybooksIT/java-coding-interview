package coding.challenge.good;

public interface Connection {
    public void connect();
}