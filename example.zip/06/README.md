# 객체지향 프로그래밍(Object-Oriented Programming)
이 장에서는 SOLID 원칙과 주크박스(Jukebox), 주차장(Parking Lot), 해시 테이블(Hash Table)과 같은 코딩 테스트 등 자바 관련 기술 인터뷰에서 접하는 객체지향 프로그래밍의 가장 인기 있는 질문과 문제를 설명합니다.