package coding.challenge;

public class Main {
    public static void main(String[] args) {
        int number = 4;

        System.out.println("Result: " + Bits.findPosition(number));
    }
}