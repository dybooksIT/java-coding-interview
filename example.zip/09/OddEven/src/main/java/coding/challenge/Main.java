package coding.challenge;

public class Main {
    public static void main(String[] args) {
        System.out.println("2 -> " + Bits.isOdd(2));
        System.out.println("3 -> " + Bits.isOdd(3));
        System.out.println("4 -> " + Bits.isOdd(4));
        System.out.println("5 -> " + Bits.isOdd(5));
        System.out.println("6 -> " + Bits.isOdd(6));
        System.out.println("7 -> " + Bits.isOdd(7));
        System.out.println("8 -> " + Bits.isOdd(8));
        System.out.println("9 -> " + Bits.isOdd(9));
        System.out.println("10 -> " + Bits.isOdd(10));
        System.out.println("12453 -> " + Bits.isOdd(12453));
        System.out.println("12988 -> " + Bits.isOdd(12988));
    }
}