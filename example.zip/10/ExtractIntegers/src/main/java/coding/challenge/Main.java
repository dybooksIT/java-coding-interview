package coding.challenge;

public class Main {
    public static void main(String[] args) {
        String str = "cv dd 4 k 2321 2 11 k4k2 66 4d";

        System.out.println("String: " + str);
        System.out.println("Integers : " + Strings.extract(str));
    }
}